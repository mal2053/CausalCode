function nbasis = getnbasis(basisobj)
%  GETNBASIS   Extracts the type of basis from basis object BASISOBJ.

%  last modified 1 November 2007

  if ~isa_basis(basisobj)
    error('Argument is not a functional basis object.');
  end

  nbasis = basisobj.nbasis - length(basisobj.dropind);
