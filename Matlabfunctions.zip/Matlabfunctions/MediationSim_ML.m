y = zeros(20,60);
h = HRF(1);
Z = [zeros(20,1); h'; zeros(10,1)];

d = unifrnd(0,10,20,1)+40;
p = 0.5*d +normrnd(0,1,20,1);
p = p - min(p);
p = 2*p;
p = round(p);
for i=1:20, y(i,:) = (p(i)+normrnd(0,1))*Z' + normrnd(0,1,1,60); end;

Dat = y';


% x -> m

N = 20;
T = 1;
timevec = linspace(0,T,60)';

nbasis = 20;
norder = 6;
basis = create_bspline_basis([0,T], nbasis, norder);
Datfd = data2fd(Dat, timevec, basis);
yfdPar = fdPar(Datfd);



conbas = create_constant_basis([0,T]);
confd  = fd(ones(1,N),conbas);

basisobj2 = create_bspline_basis([0,T],nbasis,norder);
coef2 = randn(nbasis,N);
xobj2 = fd(coef2, basisobj2);

xfdcell = cell(1,2);
xfdcell{1} = confd;
% xfdcell{2} = xobj2;
xfdcell{2} = d;

betacell = cell(1,2);
betabasis = create_bspline_basis([0,T],nbasis,norder);
betafd1 = fd(1, conbas);
betacell{1} = fdPar(betafd1);
betafdj = fd(zeros(N,1),betabasis);
betacell{2} = fdPar(betafdj);


fRegressCell = fRegress(yfdPar, xfdcell, betacell);

betaestcell = fRegressCell{4};

% tfine = linspace(0,T,60)';
% for j=1:2
%     subplot(2,1,j)
%     plot(tfine, eval_fd(tfine,getfd(betaestcell{j})), '-')
% end

alpha = getfd(betaestcell{2});


% m -> y


T = 1;
timevec = linspace(0,T,60)';

xfdcell = cell(1,3);
conbas = create_constant_basis([0,T]);
confd  = fd(ones(1,N),conbas);
xfdcell{1} = confd;
basis = create_bspline_basis([0,T], nbasis, norder);
xfdcell{2} = data2fd(Dat, timevec, basis);
xfdcell{3} = fd(d',conbas);


yfdPar = p;


betacell = cell(1,3);
betafd1 = fd(1, conbas);
betacell{1} = fdPar(betafd1);
betafdj = fd(zeros(N,1),basis);
estimate  = 1;
lambda    = 1e2;
betafdPar = fdPar(betafdj, estimate, lambda);
betacell{2} = betafdPar;
betacell{3} = fdPar(betafd1);

fRegressCell = fRegress(yfdPar, xfdcell, betacell);

betaestcell = fRegressCell{4};

tfine = linspace(0,T,60)';
% for j=1:3
%     subplot(3,1,j)
%     plot(tfine, eval_fd(tfine,getfd(betaestcell{j})), '-')
% end


beta = getfd(betaestcell{2});



abf = eval_fd(tfine,alpha.*beta);
ab = sum(abf)*(tfine(2)-tfine(1));

tmp = eval_fd(tfine,getfd(betaestcell{3}));
cp = tmp(1);



% x -> y

T = 1;
timevec = linspace(0,T,60)';

xfdcell = cell(1,2);
conbas = create_constant_basis([0,T]);
confd  = fd(ones(1,N),conbas);
xfdcell{1} = confd;
xfdcell{2} = fd(d',conbas);


yfdPar = p;


betacell = cell(1,2);
betafd1 = fd(1, conbas);
betacell{1} = fdPar(betafd1);
betacell{2} = fdPar(betafd1);

fRegressCell = fRegress(yfdPar, xfdcell, betacell);

betaestcell = fRegressCell{4};

tfine = linspace(0,T,60)';
% for j=1:2
%     subplot(2,1,j)
%     plot(tfine, eval_fd(tfine,getfd(betaestcell{j})), '-')
% end



tmp = eval_fd(tfine,getfd(betaestcell{2}));
c = tmp(1);



subplot(3,1,1)
plot(tfine, eval_fd(tfine, alpha));
subplot(3,1,2)
plot(tfine, eval_fd(tfine,beta));
subplot(3,1,3)
plot(abf);



fprintf('Parameter \n');
fprintf('c      %3.3f \n', c)
fprintf('cp     %3.3f \n', cp)
fprintf('ab     %3.3f \n', ab)

