function [stats] = fMediationTest(out, reps,nbasis,norder, varargin)

m = out.m;
x = out.x;
y = out.y;

[len, N] = size(m);
T = 1;
timevec = linspace(0,T,len);
    
% Create bspline basis set
% nbasis = 20;
% norder = 6;

estimate  = 2;
lambda    = 10;  

for varg = 1:length(varargin)
        if ischar(varargin{varg})
            switch varargin{varg}
                % reserved keywords
                case {'estimate'}, estimate = varargin{varg+1};
                case {'lambda'} , lambda = varargin{varg+1};
                otherwise, disp(['Unknown input string option: ' varargin{varg}]);
            
            end
        end
end

basis = create_bspline_basis([0,T], nbasis, norder);    

abMat = zeros(reps,1);
abfMat = zeros(reps,len);
abIVMat = zeros(reps,len);
afMat = zeros(reps,len);
bfMat = zeros(reps,len);

for i=1:reps,

    [tmp,samp] = sort(rand(N,1));
    mm = m(:,samp);
    xx = x;

%     [tmp,samp2] = sort(rand(N,1));
%     xx = x(samp2);

    yy = y;

    [res] = fMediation(xx,yy,mm,nbasis,norder);
                                            
    abMat(i) = res.ab;
    abfMat(i,:) = res.abfunction';
    abIVMat(i,:) = res.abIV';
    afMat(i,:) = res.afunction';
    bfMat(i,:) = res.bfunction';
end                      
    
stats = struct('abfunction', out.abfunction, 'abMat', abMat, 'abfMat', abfMat, 'afMat', afMat, 'bfMat', bfMat,'abIVMat', abIVMat, 'reps', reps);


end 


%%

function [out] = fMediation(x,y,m,nbasis,norder, varargin)

[len, N] = size(m);
T = 1;
timevec = linspace(0,T,len);

estimate  = 2;
lambda    = 10;  
pen = 0.1;

for varg = 1:length(varargin)
        if ischar(varargin{varg})
            switch varargin{varg}
                % reserved keywords
                case {'penalty'}, pen = varargin{varg+1};
                case {'estimate'}, estimate = varargin{varg+1};
                case {'lambda'} , lambda = varargin{varg+1};
                otherwise, disp(['Unknown input string option: ' varargin{varg}]);
            
            end
        end
end



basis = create_bspline_basis([0,T], nbasis, norder);    


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%  x -> m  %%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
% Convert time series data to functional data
mfd = data2fd(m, timevec, basis);
mfdPar = fdPar(mfd);                    % Response variable

% Create Design matrix
conbas = create_constant_basis([0,T]);
confd  = fd(ones(1,N),conbas);

xfdcell = cell(1,2);
xfdcell{1} = confd;             % Constant
xfdcell{2} = x;                 % x

% Create basis set for beta functions
betacell = cell(1,2);
betabasis = create_bspline_basis([0,T],nbasis,norder);
betafd1 = fd(1, conbas);
betacell{1} = fdPar(betafd1);
betafdj = fd(zeros(nbasis,1),betabasis);
betacell{2} = fdPar(betafdj);

% Solve least-squares equation
fRegressCell = fRegress(mfdPar, xfdcell, betacell);
betaestcell = fRegressCell{4};
afun = getfd(betaestcell{2});          % a-function

tfine = linspace(0,T,len)';
af = eval_fd(tfine,afun);               % Evaluate a-function
a = sum(af)*(tfine(2)-tfine(1));       % Integral of a-function: a = \int af(t) dt
                                       % gives a-path

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% x, m -> y %%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
% Create Design matrix
mfdcell = cell(1,3);
mfdcell{1} = confd;
basis = create_bspline_basis([0,T], nbasis, norder);
mfdcell{2} = data2fd(m, timevec, basis);
mfdcell{3} = fd(x,conbas);

% Response variable
yfdPar = y';

% Create basis set for beta functions
betacell = cell(1,3);
betafd1 = fd(1, conbas);
betacell{1} = fdPar(betafd1);
betafdj = fd(zeros(nbasis,1),basis);                          %Penalty term needed here
betafdPar = fdPar(betafdj, estimate, lambda);
betacell{2} = betafdPar;
betacell{3} = fdPar(betafd1);

% Solve least-squares equation
fRegressCell = fRegress(yfdPar, mfdcell, betacell);
betaestcell = fRegressCell{4};
bfun = getfd(betaestcell{2});           % b-function


% Calculate Standard Error
errmat = (y - fRegressCell{5}');
Sigma = errmat*errmat'/20;
DfdPar = fdPar(basis,0,1);
[fdobj, df, gcv, coef, SSE, penmat, y2cMap] = smooth_basis(timevec,m,DfdPar);
stderrCell = fRegress_stderr(fRegressCell, y2cMap, Sigma);
tmp = stderrCell{1};

b_stderr = eval_fd(tfine,tmp{2});     % Std Error of b-function


bf = eval_fd(tfine,bfun);               % Evaluate b-function
b = sum(bf)*(tfine(2)-tfine(1));        % Integral of b-function: b = \int bf(t) dt
                                        % gives b-path

abf = eval_fd(tfine,afun.*bfun);        % ab-functions
ab = sum(abf)*(tfine(2)-tfine(1));      % Integral of ab-function: ab = \int af(t)bf(t) dt
                                        % gives ab-path

                                        
tmp = eval_fd(tfine,getfd(betaestcell{3}));
cp = tmp(1);                            % c'-path


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%  x -> y  %%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
% Create Design matrix
xfdcell = cell(1,2);
conbas = create_constant_basis([0,T]);
confd  = fd(ones(1,N),conbas);
xfdcell{1} = confd;
xfdcell{2} = fd(x,conbas);

% Response variable
yfdPar = y';

% Create basis set for beta functions
betacell = cell(1,2);
betafd1 = fd(1, conbas);
betacell{1} = fdPar(betafd1);
betacell{2} = fdPar(betafd1);

% Solve least-squares equation
fRegressCell = fRegress(yfdPar, xfdcell, betacell);

betaestcell = fRegressCell{4};


tmp = eval_fd(tfine,getfd(betaestcell{2}));
c = tmp(1);                         % c-path
IV2 = c./af;

A = repmat(af',len,1);
% pen = 0.1;
IV = (inv(A'*A + pen*eye(len) )*A'*ones(len,1));

abIV = af.*IV;


% Output
out = struct('afunction', af, 'a', a, 'bfunction', bf, 'abfunction', abf, 'b', b, 'ab', ab, 'c', c, 'cp', c,'x',x, 'y', y, 'm', m,'tfine',tfine,'b_stderr',b_stderr,'IV',IV,'IV2',IV2,'abIV',abIV);

end